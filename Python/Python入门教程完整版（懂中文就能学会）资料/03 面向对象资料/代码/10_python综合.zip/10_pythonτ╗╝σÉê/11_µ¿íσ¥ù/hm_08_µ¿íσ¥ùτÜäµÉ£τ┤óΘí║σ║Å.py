import random

print(random.__file__)

rand = random.randint(0, 10)

print(rand)
