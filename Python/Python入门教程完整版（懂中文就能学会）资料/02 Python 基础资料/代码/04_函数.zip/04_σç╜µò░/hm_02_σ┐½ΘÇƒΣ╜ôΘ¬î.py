import hm_01_九九乘法表

hm_01_九九乘法表.multiple_table()
