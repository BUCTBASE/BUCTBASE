def print_line(char, times):

    print(char * times)

print_line("hi ", 40)
