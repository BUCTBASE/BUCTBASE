# 注意：定义好函数之后，之表示这个函数封装了一段代码而已
# 如果不主动调用函数，函数是不会主动执行的
def say_hello():

    print("hello 1")
    print("hello 2")
    print("hello 3")

say_hello()
