# 1. 定义苹果的单价
price = 8.5

# 2. 挑选苹果
weight = 7.5

# 3. 计算付款金额
money = weight * price

# 4. 只要买苹果，就返回 5 块钱
money = money - 5

print(money)
