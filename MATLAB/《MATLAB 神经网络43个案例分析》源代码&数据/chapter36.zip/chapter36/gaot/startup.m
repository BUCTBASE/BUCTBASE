path(path,'E:\matlab\genetic\gaot');

